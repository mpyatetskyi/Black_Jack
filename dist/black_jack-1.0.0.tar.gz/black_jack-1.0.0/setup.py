from setuptools import find_packages
from setuptools import setup

setup(
    name="black_jack",
    version="1.0.0",
    description="This package contains my version of a Black Jack game",
    author="Maksym Piatetskyi",
    author_email="m.pyatetskyi@gmail.com",
    url="https://github.com/mpyatetskyi/Black_Jack",
    install_requires=[],
    package_dir={'': 'src'},
    packages=find_packages(where='src'),

)
